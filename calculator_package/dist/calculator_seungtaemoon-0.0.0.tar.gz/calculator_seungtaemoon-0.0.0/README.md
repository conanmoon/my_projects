# Calculator
A script to perform some simple calculations that takes following inputs  
* num1: an integer, float, or even string depending on operations
* num2: an integer, float, or even string depending on operations
* choice: a type of operation to perform with two inputs

The list of operations for "choice" input:
1. "sum": sum of two numbers

2. "diff": num1 - num2

3. "-diff": num2 - num1

4. "multiply": num1 * num2

5. "divide": num1 / num2

6. "-divide": num2 / num1

7. "power": num1^(num2)

8. "-power": num2^(num1)

9. "avg": num1 + num2 / 2

10. Returns "The calculator cannot find a proper way to operate, please enter the valid inputs.", if any invalid input is given.


